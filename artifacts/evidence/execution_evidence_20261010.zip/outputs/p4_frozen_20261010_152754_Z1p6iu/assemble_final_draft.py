"""Assemble this run's manuscript; source snapshots remain append-only."""
import hashlib
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[2]
run=Path(__file__).resolve().parent
acceptance=json.loads((run/'phase_acceptance.json').read_text())
assert acceptance['passed'] and acceptance['offline_rows']==85000 and acceptance['online_rows']==107100
assert acceptance['package_sha256']=='5da3ca5eb3e80d2facf7e56017694bb437bda22c3fd6b8380f5e1c12a2602769'
base=run/'paper_before_final.tex';source=base.read_text()
source=source.replace('% Standalone development draft, 2026-10-10. Not ready for submission.','% Standalone final-experiment working draft, 2026-10-10; human author review pending.')
source=source.replace('% Final evaluation, full authors, anonymity and page size still need review.','% Final artifacts independently replayed. PDF export, pages, full authors and conference details need review.')
source=source.replace(r'\newcommand{\pending}[1]{\textbf{[Pending: #1]}}'+'\n','')
abstract=r'''\begin{abstract}
A second visual encoder can correct retrieval errors, damage correct
matches, or spend computation on queries both models miss. We compare
predicting correction minus damage with predicting fast-model error,
using five first-encoder similarity statistics and frozen global
descriptors. Models and validation thresholds are fixed before evaluating
650 Nordland holdout queries and 200 Gardens Point night queries.
With EigenPlaces as the second encoder, a nominal 25\% validation budget
transfers to 78.92\% invocation on the holdout and 15.50\% externally.
Holdout Recall@1 falls from CosPlace's 14.15\% to 10.31\%; external
Recall@1 stays at 34.50\%. With the original, weaker DINOv2 CLS model,
benefit routing largely avoids harmful holdout calls, whereas error
prediction damages accuracy. Across 107100 real online query records,
invocation alone does not determine total latency. These results support
a limited empirical conclusion: routing targets must account for model
complementarity, but a small benefit predictor does not guarantee accuracy
gain or a transferable budget. We report failures, frame-tolerance
sensitivity and data ambiguity rather than universal superiority.
\end{abstract}'''
start=source.index(r'\begin{abstract}');end=source.index(r'\end{abstract}',start)+len(r'\end{abstract}')
source=source[:start]+abstract+source[end:]
old='''Uncertainty estimation and predicting postprocessing effects have prior
work. Our intended contribution is an auditable empirical comparison
under the same available information, including a weaker second model,
a stronger specialist, and actual conditional execution. Development
results do not establish superiority of the benefit target. Prospective
evaluation will examine a held-out route block and a different day--night
collection without selecting models or thresholds from their results.'''
new='''Uncertainty estimation and predicting postprocessing effects have prior
work. Our contribution is a constrained empirical comparison under the
same available information, preserving a weaker second model and the
single development-selected specialist replacement. We examine three
failure modes: changed correction/damage opportunities, transfer of
validation budgets, and discrepancy between invocation and real execution
cost. Both final datasets use frozen models and thresholds; their results
do not select another encoder or a revised gate.'''
assert old in source;source=source.replace(old,new)
source=source.replace("normalized global CLS output, a general visual representation; this\nadapter is not AnyLoc or SALAD.","normalized global CLS output, a general visual representation.")
source=source.replace('contains 1750 aligned summer and winter\nframes.','provides 1750 summer and 1750 winter\nframes with matching numeric IDs; we evaluate this supplied frame alignment.')
source=source.replace('are the planned 650-query holdout.','form the 650-query holdout.')
source=source.replace('are planned sensitivity analyses using unchanged','are sensitivity analyses using unchanged')
source=source.replace("The planned external test uses Gardens Point's","The external test uses Gardens Point's")
source=source.replace('improve results.\n\n\\subsection{Models and Controls}','improve results. In the holdout, 187 queries belong to 79 byte-identical\ngroups; 542 unique hashes remain among 650 records. Gardens Point has\none duplicated night-image pair. These dependencies limit interpretation\nof fine frame-index errors and independent-sample claims.\n\n\\subsection{Models and Controls}')
source=source.replace('The development runtime uses an RTX 3060 Laptop GPU, PyTorch 2.6.0+cu124,\nbatch one, twenty warmup queries and three complete validation passes.','Measurements use an RTX 3060 Laptop GPU, PyTorch 2.6.0+cu124,\nbatch one, twenty warmup queries and three complete query passes.')
source=source.replace('for separately. Cached accuracy simulation is not model latency.','for separately, using warm-file construction and index setup diagnostics.\nTorch allocator peaks do not measure full-process memory; conditional\npolicies retain both encoders. Cached accuracy simulation is not model latency.')
source=source.replace(r'\section{Development Findings}',r'\section{Results}')
start=source.index(r'\subsection{Held-Out and External Results}')
end=source.index(r'\section*{Acknowledgment}',start)
elements=run/'paper_elements'
baseline=(elements/'baseline_table.tex').read_text()
table=(elements/'final_table.tex').read_text()
figure=(elements/'cost_figure.tex').read_text()
results=r'''\subsection{Frozen Final Accuracy}
Table~\ref{tab:baselines} shows substantial transfer failure. Holdout
CosPlace R@1 is 14.15\%, EigenPlaces 10.00\%, and DINOv2 3.38\%; the
specialist that was stronger in development is weaker on this block.
EigenPlaces offers only 17 rescue versus 44 harm opportunities, with
541 queries missed by both encoders. Its top-one oracle is 16.77\%.
Externally, CosPlace/EigenPlaces reach 34.50\%/36.00\%, with 31 rescue
and 28 harm opportunities; the oracle is 50.00\%. Oracle gaps measure
available top-one complementarity, not learnable or deployable performance.
All strategies and seeds are retained in the accompanying artifacts.

'''+baseline+table+r'''
\subsection{Budget Drift and Target Choice}
With frozen EigenPlaces policies, the nominal 25\% benefit setting calls
B on 78.92\% of holdout queries. Eleven rescues and 36 harms reduce
R@1 to 10.31\%, below A-only and marginally below error prediction's
10.46\%. The corresponding error and gap invocation fractions are
82.00\% and 65.08\%, not equal test costs. We therefore compare the
observed accuracy--cost points rather than asserting a matched test budget.
The nominal 10\% and 50\% benefit settings transfer to 40.15\% and
82.46\% invocation (Table~\ref{tab:final}).

In Gardens Point, the nominal 25\% benefit setting instead calls 15.50\%
of queries. Six rescues and six harms leave R@1 at 34.50\%; error
prediction calls 11.00\% and reaches 34.00\%. Benefit at nominal 50\%
reaches 36.50\% with 29.50\% invocation, only one additional correct
query over B-only. Removing standard deviation also reaches 36.50\%
at 23.00\% invocation, whereas rescue-only at 25\% reaches 34.50\%.
The feature and target ablations do not establish a uniform advantage.
Five-seed nominal-random R@1 is $13.32\pm0.37$\% on the holdout and
$35.20\pm1.60$\% externally; these are population SDs across seeds,
not confidence intervals. Validation-matched random and nominal-random
use the same EigenPlaces validation fraction, but neither enforces the
learned gate's shifted test fraction.

\subsection{Original Pair and Tolerance Sensitivity}
The original DINOv2 pair demonstrates a narrower benefit of the target.
The holdout has eight rescue and 78 harm opportunities. Benefit at nominal
25\% makes two calls, neither changing correctness, and retains A's
14.15\% R@1. Error prediction calls 82.00\%, rescues six and damages
65, reducing R@1 to 5.08\%. Externally, benefit makes 18 calls with five
rescues and three harms, reaching 35.50\%, versus error's 35.00\%.
Avoiding calls to a weak model is useful, but preserving A-only accuracy
does not establish improvement over A or superiority at equal test cost.

Tolerance changes remain separately labeled, using identical frozen
rankings and masks. At Nordland radii one/ten, A-only R@1 is
5.08\%/19.69\%, and EigenPlaces benefit-25 is 4.62\%/13.08\%.
For Gardens Point's custom radius-eight positives, A/EigenPlaces/
benefit-25/error-25 reach 97.00\%/91.00\%/93.00\%/94.00\%.
This differs markedly from exact-index results and is not the tutorial's
soft-ignore evaluation. Fine frame-index performance should not be
equated with geographic localization. Examples are the first query in
manifest order of each correctness class, not the most attractive cases;
their IDs, descriptor samples, scores and rankings are supplied.

\subsection{Real Cost and Replay Checks}
On the EigenPlaces holdout, A-only has the highest observed R@1 and the
lowest measured mean, 7.56\,ms; benefit-25 takes 13.62\,ms and B-only
10.66\,ms. Externally, benefit-25 takes 7.97\,ms versus A-only's
5.84\,ms and B-only's 8.92\,ms, with the accuracy tradeoff above.
Benefit-50 exceeds B-only by one correct query but takes 9.09\,ms,
providing no observed mean-latency saving. Figure~\ref{fig:cost} presents
actual forwards, not cached descriptor timings. Unlocked clocks and
sequential policy execution prevent attributing every timing difference
to the target or claiming stable fine-scale speedups. A reduced number
of second-model calls alone is not an end-to-end cost guarantee.

Independent replay checks all 85000 final offline rows, 107100 real
online rows and 510 strategy--radius evaluations. Descriptors are checked
against model-state and manifest hashes, row IDs, unit norms and array
hashes. Each timed pass verifies the causal decision and complete ranking
against its frozen reference outside the timer. No final fitting or
threshold calibration occurs. Gallery building and warm-file setup costs
are recorded separately; both models remain resident for conditional
execution, so invocation reduction is not a model-memory reduction.

'''+figure+r'''
\section{Discussion}
The benefit target separates two risks that A-error prediction conflates,
but the estimate is useful only if those conditional relationships transfer.
EigenPlaces rescue prevalence changes from 51/300 validation queries to
17/650 holdout queries, while harm opportunities remain material.
A-only score distributions also change: the median top1--top2 gap falls
from 0.01477 to 0.00500, and median top-ten standard deviation from
0.02477 to 0.00230. Similar top-one scores can coexist with poor
frame-index correctness. These are descriptive associations, not causal
proof that any single statistic explains the failure.

Repeated and visually similar station frames constrain the information
available to image-only retrieval. Exact Gardens Point frames penalize
nearby references that may depict similar places. We retain all queries
and report the predeclared tolerances rather than widening the primary
criterion after seeing results. Small fixed-route datasets, correlated
frames, low-resolution adaptation, linear gates and unlocked laptop clocks
limit generalization. The missing verified SU implementation limits the
uncertainty comparison. We introduce neither correction/damage labels
nor a universally better algorithm, and make no open-set, metric-pose,
SLAM or robot-deployment claim.

\section{Conclusion}
In this frozen-encoder study, predicting net correction can avoid damaging
calls to a weak second model, but neither reliable accuracy gain nor
validation-budget transfer follows. A development-selected specialist
does not preserve its advantage on a held-out route block. Reporting actual
invocation, signed corrections and real latency exposes these failures
more clearly than invocation budgets or validation Recall alone.
The results motivate testing complementarity and budget transfer before
deploying conditional retrieval; they do not establish universal benefit.

'''
source=source[:start]+results+source[end:]
assert r'\pending{' not in source
assert 'Final evaluation has not run' not in source
(ROOT/'paper/main.tex').write_text(source)
(run/'paper_final_experiment_draft.tex').write_text(source)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
metadata={'scope':'Working manuscript from independently replayed frozen final outputs; human author review required',
    'base_sha256':sha(base),'source_sha256':sha(ROOT/'paper/main.tex'),'assembler_sha256':sha(Path(__file__)),
    'acceptance_sha256':sha(run/'phase_acceptance.json'),'elements_provenance_sha256':sha(elements/'provenance.json'),
    'experimental_pending_markers':source.count(r'\pending{'),'native_pdf_export_and_page_count':'unverified',
    'rough_whitespace_word_count':len(source.split()),'additional_project_files_required':False}
(run/'paper_draft_provenance.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
