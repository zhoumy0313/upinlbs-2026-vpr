"""Inspect final figure PDFs and pass stability; no experiment changes."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2];run=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from frozen_package import validate_package

validate_package(ROOT/'outputs/freeze_review_20261010_143800/selection.json')
acceptance=json.loads((run/'phase_acceptance.json').read_text());assert acceptance['passed']
fig=run/'figures_readable_v3';provenance=json.loads((fig/'figure_provenance.json').read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,sha in provenance['output_sha256'].items():assert digest(fig/name)==sha
for name in ['all_final_metrics.csv','matching_examples.json']:
    assert digest(fig/name)==digest(run/'figures'/name)==digest(run/'figures_readable_v2'/name)
pdfs=[]
for pdf in sorted(fig.glob('*.pdf')):
    info=subprocess.run(['/usr/bin/pdfinfo',str(pdf)],capture_output=True,text=True,check=True).stdout
    fonts=subprocess.run(['/usr/bin/pdffonts',str(pdf)],capture_output=True,text=True,check=True).stdout
    assert any(l.startswith('Pages:') and l.split(':',1)[1].strip()=='1' for l in info.splitlines())
    assert fonts.splitlines()[2:] and all('TrueType' in l and l.split()[-5:-2]==['yes','yes','yes'] for l in fonts.splitlines()[2:])
    pdfs.append({'name':pdf.name,'pages':1,'embedded_truetype_fonts':True,'sha256':digest(pdf)})
assert len(pdfs)==11
assert provenance['metric_rows']==510
stability={}
for dataset in ['nordland','gardens']:
    for second in ['eigenplaces','dinov2']:
        directory=run/'results'/dataset/('pair_'+second)
        policies=json.loads((directory/'latency.json').read_text())['policies']
        key=dataset+'_'+second;stability[key]={}
        for policy,metric in policies.items():
            path=directory/(policy+'_latency.csv')
            assert digest(path)==acceptance['source_sha256'][str(path.relative_to(run))]
            rows=list(csv.DictReader(path.open()))
            means=[];details=[]
            for repeat in range(3):
                group=[r for r in rows if int(r['pass'])==repeat]
                times=np.array([float(r['total_ms']) for r in group]);means.append(float(times.mean()))
                details.append({'pass':repeat,'n_queries':len(group),'B_calls':sum(r['invoked_B']=='True' for r in group),
                    'mean_ms':float(times.mean()),'median_ms':float(np.median(times)),'p95_ms':float(np.percentile(times,95))})
            assert len(set(v['B_calls'] for v in details))==1
            np.testing.assert_allclose(np.mean(means),metric['mean_ms'],atol=1e-12)
            stability[key][policy]={'passes':details,'min_pass_mean_ms':min(means),'max_pass_mean_ms':max(means),
                'pass_mean_population_sd_ms':float(np.std(means))}
paper=(ROOT/'paper/main.tex').read_text()
for name in ['final_table.tex','baseline_table.tex','cost_figure.tex']:assert (run/'paper_elements'/name).read_text() in paper
assert r'\pending{' not in paper
compile_record=json.loads((run/'native_final_compile_attempt_1.json').read_text())
assert compile_record['result']['kind']=='success'
result={'passed':True,'figure_pdfs_checked':pdfs,'figure_numeric_records_unchanged_across_layout_revisions':True,
    'figure_metric_rows':510,'all_84_policy_passes_summarized':len(stability)*21,'runtime_pass_stability':stability,
    'paper_generated_elements_exactly_embedded':True,'native_paper_compile':'success',
    'paper_pdf_export_and_page_count':'unverified: no exported paper PDF',
    'paper_source_sha256':digest(ROOT/'paper/main.tex'),'auditor_sha256':digest(Path(__file__)),
    'timing_limit':'Sequential policy order and unlocked clocks: no cross-policy confidence intervals or isolated-head causal speed claims.'}
with (run/'rendering_acceptance.json').open('x') as stream:json.dump(result,stream,indent=2)
print(json.dumps({k:v for k,v in result.items() if k!='runtime_pass_stability'},indent=2))
