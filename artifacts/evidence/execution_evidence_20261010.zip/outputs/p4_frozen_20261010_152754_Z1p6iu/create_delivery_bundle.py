"""Local source/report bundle; exclude raw datasets, weights and credentials."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2];run=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from frozen_package import validate_package

digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=ROOT/'outputs/freeze_review_20261010_143800/selection.json'
validate_package(package)
first=json.loads((run/'phase_acceptance.json').read_text());repeat=json.loads((run/'phase_acceptance_replay_v2.json').read_text())
for key in ['passed','offline_rows','online_rows','policy_radius_evaluations','outcomes','source_sha256','package_sha256']:
    assert first[key]==repeat[key]
render=json.loads((run/'rendering_acceptance.json').read_text());assert render['passed']
assert render['paper_source_sha256']==digest(ROOT/'paper/main.tex')
assert not (ROOT/'paper/main.pdf').exists()
events=[json.loads(line) for line in (run/'commands.jsonl').read_text().splitlines()]
failures=[{'name':e['name'],'exit_status':e['exit_status']} for e in events if e['exit_status']!=0]
assert failures==[{'name':'generate_standalone_paper_elements','exit_status':1}]
for name in (run/'figures_readable_v3').glob('example_*.png'):
    assert digest(name)==digest(run/'figures'/name.name)
tracked=subprocess.check_output(['git','ls-files'],cwd=ROOT,text=True).splitlines()
files={ROOT/p for p in tracked if Path(p).parts[0] in {'src','scripts','tests','configs','docs','paper','data'} or p in {'PLAN.md','AGENTS.md','README.md','pyproject.toml','requirements.txt','.gitignore'}}
review=package.parent
files.update(p for p in review.rglob('*') if p.is_file() and p.suffix in {'.json','.yaml','.csv','.log','.py'})
files.update(p for p in run.rglob('*') if p.is_file() and p.suffix in {'.json','.jsonl','.yaml','.csv','.log','.txt','.py','.tex'} and 'figures_readable_v2' not in p.parts and 'figures' not in p.parts)
files.update(p for p in (run/'figures_readable_v3').iterdir() if p.is_file())
assert all(not any(c in p.relative_to(ROOT).parts for c in ['weights','third_party','.venv-p0','.venv-paper','raw','downloads','.git']) for p in files)
inventory={'scope':'Local working-draft handoff; no raw dataset archives or checkpoints. Matching examples requested by the user are included.',
    'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'freeze_package_sha256':digest(package),'paper_source_sha256':digest(ROOT/'paper/main.tex'),
    'final_experiments_verified':True,'goal_complete':False,
    'missing':['Independent exported paper PDF and verified total page count <=6','Human author/correspondence and official submission-detail review'],
    'experiment_rows':{k:first[k] for k in ['offline_rows','online_rows','policy_radius_evaluations']},
    'retained_failed_commands':failures,'source_and_artifact_sha256':{str(p.relative_to(ROOT)):digest(p) for p in sorted(files)}}
manifest=run/'delivery_manifest.json'
with manifest.open('x') as stream:json.dump(inventory,stream,indent=2)
archive=run/'UPINLBS_working_draft_20261010.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    for path in sorted(files):bundle.write(path,str(path.relative_to(ROOT)))
    bundle.write(manifest,str(manifest.relative_to(ROOT)))
summary={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'file_count':len(files)+1,'paper_pdf_included':False,'goal_complete':False}
with (run/'bundle_identity.json').open('x') as stream:json.dump(summary,stream,indent=2)
print(json.dumps(summary,indent=2))
