# Actual commands and exit status

|Name|Exit|Seconds|Log|
|---|---:|---:|---|
|clone_delta|0|4.976|clone_delta.log|
|fetch_conference|0|7.303|fetch_conference.log|
|download_gardens|0|11.497|download_gardens.log|
|clone_tutorial|0|17.31|clone_tutorial.log|
|delta_provenance|0|0.002|delta_provenance.log|
|tutorial_provenance|0|0.002|tutorial_provenance.log|
|fetch_conference_js|0|5.896|fetch_conference_js.log|
|nordland_range_probe|0|8.113|nordland_range_probe.log|
|download_nordland|-15|209.129|download_nordland.log|
|unit_tests_data|0|0.89|unit_tests_data.log|
|prepare_gardens|0|1.758|prepare_gardens.log|
|prepare_gardens_v2|0|1.543|prepare_gardens_v2.log|
|gardens_alignment_sheet|0|0.145|gardens_alignment_sheet.log|
|gardens_gallery_self_check|0|5.17|gardens_gallery_self_check.log|
|unit_tests_p1_final|0|0.878|unit_tests_p1_final.log|
|download_nordland_ranges|0|576.088|download_nordland_ranges.log|
|prepare_nordland_v2|0|26.354|prepare_nordland_v2.log|
|nordland_alignment_sheet|0|0.159|nordland_alignment_sheet.log|
|nordland_gallery_self_check|0|4.54|nordland_gallery_self_check.log|
|initialize_local_git|0|0.009|initialize_local_git.log|
|commit_p1_implementation|0|0.013|commit_p1_implementation.log|
|p1_source_snapshot|0|0.04|p1_source_snapshot.log|
|p1_reproduce_all|0|30.981|p1_reproduce_all.log|
|p1_acceptance|0|0.145|p1_acceptance.log|
|commit_p1_report|0|0.011|commit_p1_report.log|

## clone_delta

```bash
git clone https://github.com/oravus/DeltaDescriptors.git third_party/DeltaDescriptors
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## fetch_conference

```bash
curl --fail --location --retry 2 --connect-timeout 15 --max-time 60 --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/upinlbs2026_home.html https://upinlbs2026.com/
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## download_gardens

```bash
curl --fail --location --retry 4 --retry-all-errors --continue-at - --connect-timeout 15 --max-time 600 --output data/downloads/GardensPoint_Walking.zip https://www.tu-chemnitz.de/etit/proaut/datasets/GardensPoint_Walking.zip
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## clone_tutorial

```bash
git clone https://github.com/stschubert/VPR_Tutorial.git third_party/VPR_Tutorial
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## delta_provenance

```bash
git -C third_party/DeltaDescriptors log -1 --format=fuller
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## tutorial_provenance

```bash
git -C third_party/VPR_Tutorial log -1 --format=fuller
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## fetch_conference_js

```bash
curl --fail --location --max-time 60 --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/upinlbs2026_app.js https://upinlbs2026.com/assets/index-DYUnbZvC.js
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## nordland_range_probe

```bash
curl --fail --location --range 0-1023 --max-time 45 --dump-header /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/nordland_probe_headers.txt --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/nordland_probe.bin 'https://zenodo.org/records/4016653/files/nordland-part-2020.zip?download=1'
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## download_nordland

```bash
curl --fail --location --retry 5 --retry-all-errors --continue-at - --connect-timeout 15 --max-time 900 --output data/downloads/nordland-part-2020.zip 'https://zenodo.org/records/4016653/files/nordland-part-2020.zip?download=1'
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## unit_tests_data

```bash
.venv-p0/bin/python -m pytest -q --junitxml=/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/unit_tests.xml
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## prepare_gardens

```bash
.venv-p0/bin/python scripts/prepare_data.py --dataset gardens_point --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## prepare_gardens_v2

```bash
.venv-p0/bin/python scripts/prepare_data.py --dataset gardens_point --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## gardens_alignment_sheet

```bash
.venv-p0/bin/python scripts/plot_alignment_examples.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/gardens_point_manifest_v2.json --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/gardens_alignment.jpg
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## gardens_gallery_self_check

```bash
.venv-p0/bin/python scripts/check_gallery_self_retrieval.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/gardens_point_manifest_v2.json --dataset gardens_point --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## unit_tests_p1_final

```bash
.venv-p0/bin/python -m pytest -q
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## download_nordland_ranges

```bash
.venv-p0/bin/python scripts/download_nordland_ranges.py
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## prepare_nordland_v2

```bash
.venv-p0/bin/python scripts/prepare_data.py --dataset nordland --run-dir outputs/p1_20261010_132030
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## nordland_alignment_sheet

```bash
.venv-p0/bin/python scripts/plot_alignment_examples.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --output outputs/p1_20261010_132030/nordland_alignment.jpg
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## nordland_gallery_self_check

```bash
.venv-p0/bin/python scripts/check_gallery_self_retrieval.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --dataset nordland --run-dir outputs/p1_20261010_132030 --limit 64
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## initialize_local_git

```bash
git init --initial-branch=main
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## commit_p1_implementation

```bash
git -c user.name=Codex -c user.email=codex@localhost commit -m 'Verify dataset identities, split isolation, and gallery retrieval pipeline'
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## p1_source_snapshot

```bash
.venv-p0/bin/python scripts/snapshot_research_state.py --output outputs/p1_20261010_132030/source_snapshot.json
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## p1_reproduce_all

```bash
bash scripts/run_p1_data_audit.sh
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## p1_acceptance

```bash
.venv-p0/bin/python -c '
import csv,json,hashlib
from pathlib import Path
import numpy as np
root=Path.cwd()
run=root/"outputs/p1_20261010_132030"
repeat=root/"outputs/p1_recheck_20261010_133612_JLRNvs"
checks={}
for ds,n in [("gardens_point",200),("nordland",64)]:
 a=run/f"{ds}_manifest_v2.json";b=repeat/f"{ds}_manifest_v2.json"
 assert a.read_bytes()==b.read_bytes()
 dest=run/f"{ds}_self_retrieval";repdest=repeat/f"{ds}_self_retrieval"
 x=np.load(dest/"gallery_descriptors.npy");y=np.load(repdest/"gallery_descriptors.npy")
 assert x.shape==(n,512) and np.isfinite(x).all()
 np.testing.assert_allclose(np.linalg.norm(x,axis=1),1,atol=1e-5)
 np.testing.assert_allclose(x,y,atol=1e-6,rtol=1e-6)
 ids=json.loads((dest/"image_ids.json").read_text())
 assert ids==json.loads((repdest/"image_ids.json").read_text())
 rows=list(csv.DictReader((dest/"per_image.csv").open()))
 assert len(rows)==n and all(r["image_id"]==r["top1_image_id"] for r in rows)
 metrics=json.loads((dest/"metrics.json").read_text())
 assert metrics["cross_traverse_recall_computed"] is False
 assert metrics["top1_self_matches"]==n
 checks[ds]={"manifest_identical":True,"descriptor_repeat_max_abs_diff":float(abs(x-y).max()),"self_matches":n,"sampled_gallery":ds=="nordland"}
commands=[json.loads(l) for l in (repeat/"commands.jsonl").read_text().splitlines()]
assert_zero=all(c["exit_status"]==0 for c in commands)
assert assert_zero and len(commands)==11
assert "20 passed" in (repeat/"unit_tests.log").read_text()
audit=json.loads((run/"nordland_data_audit_v2.json").read_text())
lookup={r["image_id"]:r for r in json.loads((run/"nordland_manifest_v2.json").read_text())["records"]}
groups=audit["within_traverse_duplicate_image_groups"]
checks["nordland_duplicate_audit"]={"groups":len(groups),"images_in_groups":sum(map(len,groups)),"additional_copies":sum(len(g)-1 for g in groups),"train_validation_cross_duplicate_groups":sum({"train","validation"}<=set(lookup[i]["split"] for i in g) for g in groups)}
checks.update({"phase":"P1","status":"passed","unit_tests":20,"recheck_commands":11,"recheck_all_exit_zero":True,"final_test_metrics_computed":False,"recheck_run":str(repeat.relative_to(root))})
with (run/"phase_acceptance.json").open("x") as f:json.dump(checks,f,indent=2)
print(json.dumps(checks,indent=2))
'
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## commit_p1_report

```bash
git -c user.name=Codex -c user.email=codex@localhost commit -m 'Record P1 acceptance, reproducible commands, and research milestones'
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}
