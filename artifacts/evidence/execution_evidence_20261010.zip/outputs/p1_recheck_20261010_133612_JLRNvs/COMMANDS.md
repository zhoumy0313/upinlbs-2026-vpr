# Actual commands and exit status

|Name|Exit|Seconds|Log|
|---|---:|---:|---|
|source_snapshot|0|0.039|source_snapshot.log|
|unit_tests|0|0.656|unit_tests.log|
|verify_or_download_nordland|0|1.57|verify_or_download_nordland.log|
|prepare_gardens_point|0|1.503|prepare_gardens_point.log|
|self_gardens_point|0|5.2|self_gardens_point.log|
|alignment_gardens_point|0|0.144|alignment_gardens_point.log|
|prepare_nordland|0|16.983|prepare_nordland.log|
|self_nordland|0|3.779|self_nordland.log|
|alignment_nordland|0|0.154|alignment_nordland.log|
|dependencies|0|0.339|dependencies.log|
|dependency_lock|0|0.209|dependency_lock.log|

## source_snapshot

```bash
.venv-p0/bin/python scripts/snapshot_research_state.py --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs/source_snapshot.json
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## unit_tests

```bash
.venv-p0/bin/python -m pytest -q
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## verify_or_download_nordland

```bash
.venv-p0/bin/python scripts/download_nordland_ranges.py
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## prepare_gardens_point

```bash
.venv-p0/bin/python scripts/prepare_data.py --dataset gardens_point --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## self_gardens_point

```bash
.venv-p0/bin/python scripts/check_gallery_self_retrieval.py --dataset gardens_point --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs/gardens_point_manifest_v2.json --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs --limit 0
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## alignment_gardens_point

```bash
.venv-p0/bin/python scripts/plot_alignment_examples.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs/gardens_point_manifest_v2.json --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs/gardens_point_alignment.jpg
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## prepare_nordland

```bash
.venv-p0/bin/python scripts/prepare_data.py --dataset nordland --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## self_nordland

```bash
.venv-p0/bin/python scripts/check_gallery_self_retrieval.py --dataset nordland --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs/nordland_manifest_v2.json --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs --limit 64
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## alignment_nordland

```bash
.venv-p0/bin/python scripts/plot_alignment_examples.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs/nordland_manifest_v2.json --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_recheck_20261010_133612_JLRNvs/nordland_alignment.jpg
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## dependencies

```bash
.venv-p0/bin/python -m pip check
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## dependency_lock

```bash
.venv-p0/bin/python -m pip freeze
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}
