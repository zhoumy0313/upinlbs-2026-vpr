# Actual commands and exit status

|Name|Exit|Seconds|Log|
|---|---:|---:|---|
|source_snapshot|0|0.039|source_snapshot.log|
|unit_tests|0|0.842|unit_tests.log|
|encoder_probe|0|3.846|encoder_probe.log|
|extract_cosplace|0|26.18|extract_cosplace.log|
|extract_dinov2|0|36.824|extract_dinov2.log|
|evaluate_dev|0|1.721|evaluate_dev.log|
|matching_examples|0|0.216|matching_examples.log|
|real_latency|0|8.064|real_latency.log|
|dependencies|0|0.326|dependencies.log|

## source_snapshot

```bash
.venv-p0/bin/python scripts/snapshot_research_state.py --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p2_recheck_20261010_135136_H3hH4C/source_snapshot.json
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## unit_tests

```bash
.venv-p0/bin/python -m pytest -q
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## encoder_probe

```bash
.venv-p0/bin/python scripts/probe_frozen_encoders.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p2_recheck_20261010_135136_H3hH4C
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## extract_cosplace

```bash
.venv-p0/bin/python scripts/extract_dev_descriptors.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/nordland_manifest_v2.json --method cosplace --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p2_recheck_20261010_135136_H3hH4C
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## extract_dinov2

```bash
.venv-p0/bin/python scripts/extract_dev_descriptors.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/nordland_manifest_v2.json --method dinov2 --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p2_recheck_20261010_135136_H3hH4C
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## evaluate_dev

```bash
.venv-p0/bin/python scripts/evaluate_dev_baselines.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p2_recheck_20261010_135136_H3hH4C
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## matching_examples

```bash
.venv-p0/bin/python scripts/plot_dev_matching_examples.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p2_recheck_20261010_135136_H3hH4C
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## real_latency

```bash
.venv-p0/bin/python scripts/benchmark_dev_encoders.py --manifest /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p2_recheck_20261010_135136_H3hH4C
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## dependencies

```bash
.venv-p0/bin/python -m pip check
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}
