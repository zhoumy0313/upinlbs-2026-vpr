# 实际执行命令

本文件记录环境搭建、失败、重试与验收的实际命令。只供审查，不要把整份记录直接重跑；重复验收请运行 scripts/run_p0_smoke.sh。所有时间为 Asia/Shanghai。每步完整输出见对应日志。

## environment_before

开始：2026-10-10T11:19:27.505465+08:00；退出码：0；耗时：0.449 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[environment_before.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/environment_before.log)

```bash
python3 scripts/audit_environment.py
```

## create_venv

开始：2026-10-10T11:19:27.505666+08:00；退出码：1；耗时：0.049 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[create_venv.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/create_venv.log)

```bash
python3 -m venv .venv-p0
```

## clone_official

开始：2026-10-10T11:19:27.509580+08:00；退出码：0；耗时：5.098 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[clone_official.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/clone_official.log)

```bash
git clone --recursive https://github.com/gmberton/VPR-methods-evaluation.git third_party/VPR-methods-evaluation
```

## create_venv_without_pip

开始：2026-10-10T11:19:52.192773+08:00；退出码：0；耗时：0.036 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[create_venv_without_pip.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/create_venv_without_pip.log)

```bash
python3 -m venv --without-pip .venv-p0
```

## download_pip_bootstrap

开始：2026-10-10T11:19:52.194417+08:00；退出码：0；耗时：2.15 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[download_pip_bootstrap.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/download_pip_bootstrap.log)

```bash
curl --fail --location --max-time 120 https://bootstrap.pypa.io/get-pip.py --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/get-pip.py
```

## bootstrap_venv_pip

开始：2026-10-10T11:20:00.744384+08:00；退出码：0；耗时：5.215 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[bootstrap_venv_pip.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/bootstrap_venv_pip.log)

```bash
env PIP_CONFIG_FILE=/dev/null PIP_INDEX_URL=https://pypi.org/simple .venv-p0/bin/python /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/get-pip.py --disable-pip-version-check
```

## install_pytorch_cu124

开始：2026-10-10T11:20:19.321183+08:00；退出码：0；耗时：496.093 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[install_pytorch_cu124.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/install_pytorch_cu124.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 PIP_CONFIG_FILE=/dev/null PIP_INDEX_URL=https://download.pytorch.org/whl/cu124 .venv-p0/bin/python -m pip install torch==2.6.0 torchvision==0.21.0 --disable-pip-version-check
```

## official_git_provenance

开始：2026-10-10T11:20:20.485300+08:00；退出码：0；耗时：0.002 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/third_party/VPR-methods-evaluation

日志：[official_git_provenance.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_git_provenance.log)

```bash
git log -1 --format=fuller
```

## inspect_cosplace_hub

开始：2026-10-10T11:21:28.389710+08:00；退出码：0；耗时：1.025 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[inspect_cosplace_hub.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/inspect_cosplace_hub.log)

```bash
curl --fail --location --max-time 45 https://raw.githubusercontent.com/gmberton/CosPlace/main/hubconf.py
```

## source_preservation_check

开始：2026-10-10T11:22:54.562554+08:00；退出码：0；耗时：0.027 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[source_preservation_check.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/source_preservation_check.log)

```bash
python3 -c 'import hashlib,json,pathlib; root=pathlib.Path.cwd(); hashes=json.loads(pathlib.Path("/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/source_hashes.json").read_text()); actual={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in hashes}; assert hashes==actual; print(json.dumps({"existing_project_files_unchanged":True,"checked_file_count":len(hashes),"protocol_sha256":actual["configs/protocol.yaml"]},indent=2))'
```

## shell_script_syntax

开始：2026-10-10T11:26:59.509207+08:00；退出码：0；耗时：0.002 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[shell_script_syntax.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/shell_script_syntax.log)

```bash
bash -n scripts/run_p0_smoke.sh
```

## helper_syntax

开始：2026-10-10T11:26:59.591593+08:00；退出码：0；耗时：0.03 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[helper_syntax.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/helper_syntax.log)

```bash
python3 -m py_compile scripts/record_command.py scripts/audit_environment.py scripts/check_torch_gpu.py scripts/inspect_toy_outputs.py
```

## inspect_cosplace_network

开始：2026-10-10T11:27:14.494095+08:00；退出码：0；耗时：2.012 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[inspect_cosplace_network.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/inspect_cosplace_network.log)

```bash
curl --fail --location --max-time 45 https://raw.githubusercontent.com/gmberton/CosPlace/main/cosplace_model/cosplace_network.py
```

## gpu_probe

开始：2026-10-10T11:28:44.464070+08:00；退出码：0；耗时：2.665 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[gpu_probe.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/gpu_probe.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 .venv-p0/bin/python scripts/check_torch_gpu.py
```

## install_core_and_official_deps

开始：2026-10-10T11:28:45.612219+08:00；退出码：0；耗时：75.195 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[install_core_and_official_deps.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/install_core_and_official_deps.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 PIP_CONFIG_FILE=/dev/null PIP_INDEX_URL=https://pypi.org/simple .venv-p0/bin/python -m pip install -r requirements-core.txt -r third_party/VPR-methods-evaluation/requirements.txt --disable-pip-version-check
```

## official_help

开始：2026-10-10T11:30:29.601216+08:00；退出码：0；耗时：3.258 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/third_party/VPR-methods-evaluation

日志：[official_help.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_help.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/.venv-p0/bin/python main.py --help
```

## dependency_check

开始：2026-10-10T11:30:29.602499+08:00；退出码：0；耗时：0.382 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[dependency_check.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/dependency_check.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 .venv-p0/bin/python -m pip check
```

## unit_tests

开始：2026-10-10T11:30:29.602504+08:00；退出码：0；耗时：0.797 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[unit_tests.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/unit_tests.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 .venv-p0/bin/python -m pytest -q --junitxml=/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/unit_tests.xml
```

## official_toy

开始：2026-10-10T11:30:43.356232+08:00；退出码：1；耗时：9.99 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/third_party/VPR-methods-evaluation

日志：[official_toy.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_toy.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 TORCH_HOME=/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/.venv-p0/bin/python main.py --method=cosplace --backbone=ResNet18 --descriptors_dimension=512 --database_folder=toy_dataset/database --queries_folder=toy_dataset/queries --no_labels --image_size 200 200 --num_preds_to_save 3 --device cuda --batch_size 1 --num_workers 0 --save_descriptors --log_dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_toy
```

## requirements_freeze

开始：2026-10-10T11:30:44.516500+08:00；退出码：0；耗时：0.207 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[requirements_freeze.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/requirements_freeze.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 .venv-p0/bin/python -m pip freeze
```

## download_resnet18_verified_retry

开始：2026-10-10T11:31:13.410812+08:00；退出码：56；耗时：3.011 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[download_resnet18_verified_retry.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/download_resnet18_verified_retry.log)

```bash
curl --fail --location --retry 3 --connect-timeout 15 --max-time 180 --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/resnet18-f37072fd.pth.download 'https://download.pytorch.org/models/resnet18-f37072fd.pth?download=1'
```

## resume_resnet18

开始：2026-10-10T11:31:35.268431+08:00；退出码：0；耗时：23.206 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[resume_resnet18.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/resume_resnet18.log)

```bash
curl --fail --location --retry 8 --retry-all-errors --retry-delay 1 --continue-at - --connect-timeout 15 --max-time 180 --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/resnet18-f37072fd.pth.download 'https://download.pytorch.org/models/resnet18-f37072fd.pth?download=1'
```

## final_environment

开始：2026-10-10T11:31:36.445733+08:00；退出码：0；耗时：0.495 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[final_environment.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/final_environment.log)

```bash
python3 scripts/audit_environment.py
```

## verify_resnet18_checkpoint

开始：2026-10-10T11:32:07.028810+08:00；退出码：0；耗时：0.09 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[verify_resnet18_checkpoint.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/verify_resnet18_checkpoint.log)

```bash
python3 -c 'import pathlib,hashlib,shutil,json; p=pathlib.Path("/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/resnet18-f37072fd.pth.download"); h=hashlib.sha256(p.read_bytes()).hexdigest(); assert h.startswith("f37072fd"), h; target=pathlib.Path("weights/p0_torch/hub/checkpoints/resnet18-f37072fd.pth"); assert not target.exists(); shutil.copy2(p,target); print(json.dumps({"sha256":h,"bytes":p.stat().st_size,"official_hash_prefix_matches":True,"cache":str(target)},indent=2))'
```

## official_toy_retry

开始：2026-10-10T11:32:13.141769+08:00；退出码：1；耗时：8.047 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/third_party/VPR-methods-evaluation

日志：[official_toy_retry.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_toy_retry.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 TORCH_HOME=/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/.venv-p0/bin/python main.py --method=cosplace --backbone=ResNet18 --descriptors_dimension=512 --database_folder=toy_dataset/database --queries_folder=toy_dataset/queries --no_labels --image_size 200 200 --num_preds_to_save 3 --device cuda --batch_size 1 --num_workers 0 --save_descriptors --log_dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_toy_retry
```

## preserve_truncated_cosplace_checkpoint

开始：2026-10-10T11:32:42.636373+08:00；退出码：0；耗时：0.043 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[preserve_truncated_cosplace_checkpoint.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/preserve_truncated_cosplace_checkpoint.log)

```bash
python3 -c 'from pathlib import Path; import shutil,hashlib,json; p=Path("weights/p0_torch/hub/checkpoints/ResNet18_512_cosplace.pth"); failed=Path("/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/ResNet18_512_cosplace.truncated.pth"); assert not failed.exists(); h=hashlib.sha256(p.read_bytes()).hexdigest(); n=p.stat().st_size; p.rename(failed); shutil.copy2(failed,Path("/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/ResNet18_512_cosplace.pth.download")); print(json.dumps({"retained_failed_file":str(failed),"bytes":n,"sha256":h},indent=2))'
```

## resume_cosplace_checkpoint

开始：2026-10-10T11:32:42.761713+08:00；退出码：0；耗时：11.196 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[resume_cosplace_checkpoint.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/resume_cosplace_checkpoint.log)

```bash
curl --fail --location --retry 8 --retry-all-errors --retry-delay 1 --continue-at - --connect-timeout 15 --max-time 180 --output /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/ResNet18_512_cosplace.pth.download https://github.com/gmberton/CosPlace/releases/download/v1.0/ResNet18_512_cosplace.pth
```

## verify_cosplace_checkpoint

开始：2026-10-10T11:33:02.388705+08:00；退出码：0；耗时：1.512 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[verify_cosplace_checkpoint.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/verify_cosplace_checkpoint.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 .venv-p0/bin/python -c 'from pathlib import Path; import torch,hashlib,shutil,json; p=Path("/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/ResNet18_512_cosplace.pth.download"); state=torch.load(p,map_location="cpu",weights_only=True); assert state["aggregation.3.weight"].shape==(512,512); assert all(isinstance(v,torch.Tensor) and torch.isfinite(v).all() for v in state.values()); target=Path("weights/p0_torch/hub/checkpoints/ResNet18_512_cosplace.pth"); assert not target.exists(); shutil.copy2(p,target); print(json.dumps({"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size,"state_dict_entries":len(state),"finite_tensors_only":True,"aggregation_weight_shape":list(state["aggregation.3.weight"].shape),"official_published_full_sha256":"not provided by upstream hubconf; digest records exact local file"},indent=2))'
```

## official_toy_success

开始：2026-10-10T11:33:14.393461+08:00；退出码：0；耗时：4.659 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/third_party/VPR-methods-evaluation

日志：[official_toy_success.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_toy_success.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 TORCH_HOME=/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/.venv-p0/bin/python main.py --method=cosplace --backbone=ResNet18 --descriptors_dimension=512 --database_folder=toy_dataset/database --queries_folder=toy_dataset/queries --no_labels --image_size 200 200 --num_preds_to_save 3 --device cuda --batch_size 1 --num_workers 0 --save_descriptors --log_dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_toy_success
```

## inspect_toy

开始：2026-10-10T11:33:31.437830+08:00；退出码：0；耗时：2.863 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[inspect_toy.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/inspect_toy.log)

```bash
env PYTHONPATH= PYTHONNOUSERSITE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 .venv-p0/bin/python scripts/inspect_toy_outputs.py --run-dir /home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919
```

## official_source_unchanged

开始：2026-10-10T11:33:32.594660+08:00；退出码：0；耗时：0.013 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/third_party/VPR-methods-evaluation

日志：[official_source_unchanged.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_source_unchanged.log)

```bash
git status --short
```

## environment_after_toy

开始：2026-10-10T11:34:43.184565+08:00；退出码：0；耗时：0.443 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[environment_after_toy.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/environment_after_toy.log)

```bash
python3 scripts/audit_environment.py
```

## official_submodule_provenance

开始：2026-10-10T11:34:43.187055+08:00；退出码：0；耗时：0.027 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/third_party/VPR-methods-evaluation

日志：[official_submodule_provenance.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/official_submodule_provenance.log)

```bash
git submodule status
```

## system_python_preservation

开始：2026-10-10T11:34:43.188126+08:00；退出码：0；耗时：0.022 s。
工作目录：/home/aaron/upinlbs_vpr/upinlbs_vpr_starter

日志：[system_python_preservation.log](/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/outputs/p0_20261010_111919/system_python_preservation.log)

```bash
python3 -c 'import sys,importlib.util,json; print(json.dumps({"executable":sys.executable,"version":sys.version,"global_pip_present":importlib.util.find_spec("pip") is not None},indent=2))'
```
