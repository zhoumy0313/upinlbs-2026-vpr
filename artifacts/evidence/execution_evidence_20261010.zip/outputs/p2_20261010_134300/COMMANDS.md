# Actual commands and exit status

|Name|Exit|Seconds|Log|
|---|---:|---:|---|
|clone_cosplace|0|1.474|clone_cosplace.log|
|clone_dinov2|0|2.351|clone_dinov2.log|
|download_dinov2|56|4.63|download_dinov2.log|
|download_dinov2_resume|0|11.364|download_dinov2_resume.log|
|verify_checkpoints|0|1.785|verify_checkpoints.log|
|encoder_probe|1|3.498|encoder_probe.log|
|clone_selective_matching|0|2.032|clone_selective_matching.log|
|clone_smr|0|2.397|clone_smr.log|
|encoder_probe_float32|0|4.177|encoder_probe_float32.log|
|extract_cosplace_dev|0|23.249|extract_cosplace_dev.log|
|extract_dinov2_dev|0|36.707|extract_dinov2_dev.log|
|unit_tests_p2|0|0.94|unit_tests_p2.log|
|fetch_su_accepted_pdf|35|16.615|fetch_su_accepted_pdf.log|
|evaluate_dev|0|1.947|evaluate_dev.log|
|su_pdf_text|1|0.008|su_pdf_text.log|
|baseline_real_latency|0|8.726|baseline_real_latency.log|
|baseline_real_latency_quiet|0|8.178|baseline_real_latency_quiet.log|
|fetch_su_accepted_pdf_tls12|35|42.013|fetch_su_accepted_pdf_tls12.log|
|matching_examples|0|0.216|matching_examples.log|
|fetch_su_pdf_direct|28|15.009|fetch_su_pdf_direct.log|
|source_literature_snapshot|0|0.037|source_literature_snapshot.log|
|project_source_snapshot|0|0.041|project_source_snapshot.log|
|p2_complete_reproduction|0|78.391|p2_complete_reproduction.log|
|phase_acceptance|0|1.162|phase_acceptance.log|
|project_source_snapshot_final|0|0.04|project_source_snapshot_final.log|

## clone_cosplace

```bash
git clone https://github.com/gmberton/CosPlace.git third_party/CosPlace
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## clone_dinov2

```bash
git clone https://github.com/facebookresearch/dinov2.git third_party/dinov2
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## download_dinov2

```bash
curl --fail --location --retry 3 --continue-at - --output weights/p0_torch/hub/checkpoints/dinov2_vits14_pretrain.pth https://dl.fbaipublicfiles.com/dinov2/dinov2_vits14/dinov2_vits14_pretrain.pth
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## download_dinov2_resume

```bash
curl --fail --location --retry 5 --retry-all-errors --continue-at - --output weights/p0_torch/hub/checkpoints/dinov2_vits14_pretrain.pth https://dl.fbaipublicfiles.com/dinov2/dinov2_vits14/dinov2_vits14_pretrain.pth
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## verify_checkpoints

```bash
.venv-p0/bin/python -c 'import torch,hashlib,json,pathlib; files=list(pathlib.Path("weights/p0_torch/hub/checkpoints").glob("*.pth")); print(json.dumps([{ "file":str(p),"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"state_tensors":len(torch.load(p,map_location="cpu",weights_only=True)),"finite":all(torch.isfinite(v).all().item() for v in torch.load(p,map_location="cpu",weights_only=True).values())} for p in files],indent=2))'
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## encoder_probe

```bash
.venv-p0/bin/python scripts/probe_frozen_encoders.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir outputs/p2_20261010_134300
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## clone_selective_matching

```bash
git clone https://github.com/FarInHeight/To-Match-or-Not-to-Match.git third_party/To-Match-or-Not-to-Match
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## clone_smr

```bash
git clone https://github.com/QVPR/vpr-smr-predictor.git third_party/vpr-smr-predictor
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## encoder_probe_float32

```bash
.venv-p0/bin/python scripts/probe_frozen_encoders.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir outputs/p2_20261010_134300
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## extract_cosplace_dev

```bash
.venv-p0/bin/python scripts/extract_dev_descriptors.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --method cosplace --run-dir outputs/p2_20261010_134300
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## extract_dinov2_dev

```bash
.venv-p0/bin/python scripts/extract_dev_descriptors.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --method dinov2 --run-dir outputs/p2_20261010_134300
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4"}

## unit_tests_p2

```bash
.venv-p0/bin/python -m pytest -q
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## fetch_su_accepted_pdf

```bash
curl --fail --location --retry 2 --output outputs/p2_20261010_134300/SU_accepted_2026.pdf https://repository.essex.ac.uk/43511/1/25-5019_03_MS.pdf
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## evaluate_dev

```bash
.venv-p0/bin/python scripts/evaluate_dev_baselines.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir outputs/p2_20261010_134300
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "OMP_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## su_pdf_text

```bash
pdftotext -layout outputs/p2_20261010_134300/SU_accepted_2026.pdf outputs/p2_20261010_134300/SU_accepted_2026.txt
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## baseline_real_latency

```bash
.venv-p0/bin/python scripts/benchmark_dev_encoders.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir outputs/p2_20261010_134300
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## baseline_real_latency_quiet

```bash
.venv-p0/bin/python scripts/benchmark_dev_encoders.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir outputs/p2_20261010_134300 --output-dir outputs/p2_20261010_134300/quiet_latency
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1", "TORCH_HOME": "/home/aaron/upinlbs_vpr/upinlbs_vpr_starter/weights/p0_torch", "OMP_NUM_THREADS": "4", "MKL_NUM_THREADS": "4", "OPENBLAS_NUM_THREADS": "4"}

## fetch_su_accepted_pdf_tls12

```bash
curl --fail --location --http1.1 --tls-max 1.2 --retry 2 --retry-all-errors --max-time 45 --output outputs/p2_20261010_134300/SU_accepted_2026.pdf https://repository.essex.ac.uk/43511/1/25-5019_03_MS.pdf
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## matching_examples

```bash
.venv-p0/bin/python scripts/plot_dev_matching_examples.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir outputs/p2_20261010_134300
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## fetch_su_pdf_direct

```bash
curl --fail --location --noproxy repository.essex.ac.uk --connect-timeout 15 --max-time 35 --output outputs/p2_20261010_134300/SU_accepted_2026.pdf https://repository.essex.ac.uk/43511/1/25-5019_03_MS.pdf
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## source_literature_snapshot

```bash
python3 -c 'import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();run=root/"outputs/p2_20261010_134300"
items={}
for directory,names in {
"vpr-smr-predictor":["tools/mlp_classifier.py","train.py","README.md"],
"To-Match-or-Not-to-Match":["match_queries_preds.py","reranking.py","vpr_uncertainty/eval.py","vpr_uncertainty/baselines.py"],
"dinov2":["dinov2/hub/backbones.py","dinov2/data/transforms.py","dinov2/models/vision_transformer.py"],
"CosPlace":["hubconf.py","cosplace_model/cosplace_network.py"]
}.items():
 folder=root/"third_party"/directory
 items[directory]={"commit":subprocess.check_output(["git","-C",str(folder),"rev-parse","HEAD"],text=True).strip(),"sha256":{n:hashlib.sha256((folder/n).read_bytes()).hexdigest() for n in names}}
items["SU"]={"preprint":"https://arxiv.org/html/2510.13464v1","accepted_record":"https://repository.essex.ac.uk/43511/","accepted_pdf":"https://repository.essex.ac.uk/43511/1/25-5019_03_MS.pdf","status":"Preprint methods III and IV-C read; accepted first3 pages read via web; local download failed. No verified official code, no comparator implemented.","parameters_seen_in_preprint":{"k":10,"alpha":0.5},"zero_denominator_convention":"unverified"}
with (run/"literature_source_snapshot.json").open("x") as f:json.dump(items,f,indent=2)
print(run/"literature_source_snapshot.json")
'
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## project_source_snapshot

```bash
.venv-p0/bin/python scripts/snapshot_research_state.py --output outputs/p2_20261010_134300/source_snapshot.json
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## p2_complete_reproduction

```bash
bash scripts/run_p2_dev_baselines.sh
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}

## phase_acceptance

```bash
.venv-p0/bin/python scripts/verify_p2_artifacts.py --manifest outputs/p1_20261010_132030/nordland_manifest_v2.json --run-dir outputs/p2_20261010_134300 --repeat-dir outputs/p2_recheck_20261010_135136_H3hH4C
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {"PYTHONPATH": "", "PYTHONNOUSERSITE": "1"}

## project_source_snapshot_final

```bash
.venv-p0/bin/python scripts/snapshot_research_state.py --output outputs/p2_20261010_134300/source_snapshot_final.json
```

cwd: /home/aaron/upinlbs_vpr/upinlbs_vpr_starter
Environment overrides: {}
