import hashlib,json,re,sys,zipfile
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path.cwd();out=ROOT/'outputs/p5_pdf_acceptance_20261010_193746'
sys.path.insert(0,str(ROOT/'scripts'))
from frozen_package import validate_package
read=lambda p:json.loads((ROOT/p).read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p0=read('outputs/p0_recheck_20261010_113854_OTajtv/goal_acceptance.json')
p1=read('outputs/p1_20261010_132030/phase_acceptance.json')
p2=read('outputs/p2_20261010_134300/phase_acceptance.json')
p3=read('outputs/p3_eigenplaces_20261010_141736_ayAvV5/phase_acceptance.json')
p4=read('outputs/p4_frozen_20261010_152754_Z1p6iu/phase_acceptance.json')
p4repeat=read('outputs/p4_frozen_20261010_152754_Z1p6iu/phase_acceptance_replay_v2.json')
p5=read('outputs/p5_pdf_acceptance_20261010_193746/pdf_acceptance.json')
repeat=read('outputs/p5_pdf_acceptance_20261010_193746/pdf_acceptance_recheck_1.json')
assert p0['all_recorded_commands_exit_zero'] and p0['synthetic_tests_passed']==12
assert p0['database_images']==17 and p0['query_images']==5 and p0['original_project_files_unchanged']
assert p0['top3_ids_and_scores_identical_to_previous_run']
assert p1['status']=='passed' and p1['recheck_all_exit_zero'] and p1['gardens_point']['self_matches']==200 and p1['nordland']['self_matches']==64
assert p2['status']=='passed' and p2['baseline_and_complementarity_repeat_identical']
assert not p2['final_test_metrics_computed'] and not p3['final_test_used']
assert p3['passed'] and p3['policy_count']==50
for k in ['passed','offline_rows','online_rows','policy_radius_evaluations','outcomes','source_sha256','package_sha256']:
 assert p4[k]==p4repeat[k]
assert p4['passed'] and (p4['offline_rows'],p4['online_rows'],p4['policy_radius_evaluations'])==(85000,107100,510)
package=ROOT/'outputs/freeze_review_20261010_143800/selection.json'
validate_package(package)
confirmation=read('outputs/freeze_review_20261010_143800/human_confirmation.json')
events=list(map(json.loads,(ROOT/'outputs/p4_frozen_20261010_152754_Z1p6iu/commands.jsonl').read_text().splitlines()))
final=[e for e in events if e['name']=='final_evaluation'];assert len(final)==1 and final[0]['exit_status']==0
assert datetime.fromisoformat(confirmation['recorded_at'])<datetime.fromisoformat(final[0]['started_at'])
assert p5['passed'] and repeat['passed'] and p5['pages']==5 and p5['references_included_in_page_count']
assert p5['source_sha256']==sha(ROOT/'paper/main.tex') and p5['pdf_sha256']==sha(ROOT/'paper/main.pdf')
assert len(p5['embedded_fonts'])==19 and p5['final_numeric_cells_verified']==100
assert p5['all_pages_rendered_and_visually_reviewed'] and p5['figure_source_point_count']==38
conference=read('outputs/p1_20261010_132030/conference_requirements.json')
assert conference['confirmed']['full_paper_limit_pages']==6
assert conference['frontend_bundle_sha256']==sha(ROOT/'outputs/p1_20261010_132030/upinlbs2026_app.js')
assert p5['pages']<=conference['confirmed']['full_paper_limit_pages']
bundle=read('outputs/handoff_pdf_20261010_194500/bundle_acceptance.json');assert bundle['passed'] and bundle['paper_pdf_included']
archive=Path(bundle['archive']);assert sha(archive)==bundle['sha256']
manifest=read('outputs/handoff_pdf_20261010_194500/delivery_manifest.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in manifest['source_and_artifact_sha256'].items():
  assert hashlib.sha256(z.read(name)).hexdigest()==h,name
 assert z.read('paper/main.tex')==(ROOT/'paper/main.tex').read_bytes()
 assert z.read('paper/main.pdf')==(ROOT/'paper/main.pdf').read_bytes()
 assert len([n for n in z.namelist() if '/figures_readable_v3/example_' in n and n.endswith('.png')])==8
 assert len([n for n in z.namelist() if 'p0_recheck_20261010_113854_OTajtv/official_toy/' in n and n.endswith('.jpg')])==5
 for name in ['PLAN.md','AGENTS.md','configs/protocol.yaml','docs/P0_ENVIRONMENT_REPORT.md','docs/P1_DATA_PIPELINE_REPORT.md','docs/P2_DEV_BASELINE_REPORT.md','docs/P3_SELECTOR_REPORT.md','docs/P4_FINAL_EXPERIMENT_REPORT.md','docs/P5_PDF_ACCEPTANCE_REPORT.md','docs/PAPER_REFERENCES_AUDIT.md','docs/PAPER_EVIDENCE_MAP.md','docs/SUBMISSION_CHECKLIST.md']:
  assert name in z.namelist(),name
checks={
 'existing_Ubuntu_environment_and_GPU_audit_preserved':'P0 original preservation acceptance, recorded environment/driver/network/Python audits and CUDA probe; no system configuration changes in subsequent project commands',
 'isolated_environment_units_and_official_CosPlace_toy':'P0 accepted repeat: 12 tests, 17 gallery/5 queries, matching ranks reproduced',
 'pipeline_data_ID_ground_truth_and_retrieval':'P1 accepted decoding/manifests and self-retrieval repeat; GTsoft custom-tolerance distinction preserved',
 'frozen_baseline_reproduction':'P2 both models repeated identically in declared 224-pixel setting, 22 tests, cache-fault guards; original-paper numeric reproduction not claimed',
 'problem_analysis_method_implementation_controls_and_ablations':'P3 both pairs and all policies/seeds, one validation-selected replacement, negative results and literature limitations retained; universal improvement not claimed',
 'freeze_and_final_experiments':'Actual user confirmation predates P4 access; protected scientific package validates; two complete independent audits agree for all 85000/107100/510 records',
 'real_runtime_and_matching_explanation':'Actual three-pass encoding logs, startup/memory diagnostics, eight final matching strips and five official toy strips are in archive',
 'paper_source_citations_disclosure_compile':'Current source matches final-experiment provenance; native compiler success and reference audit retained; AI use disclosed',
 'at_most_six_page_PDF_fonts_layout_and_numbers':'User-exported PDF is 5 pages including references, all 19 fonts embedded, all pages inspected, final 100 table cells match logs',
 'official_requirements_checked_and_uncertainty_documented':'Archived official frontend hash and 6-page requirement verified; unstated details remain explicit author-review items',
 'full_local_delivery_code_commands_logs_artifacts':'Complete archive CRC and every member hash independently checked; current source/PDF exactly included',
 'no_unauthorized_external_action':'Local artifacts only; no submission, payment, copyright signing, author invention or outbound messaging'
}
result={'passed':True,'checked_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'scope':'User-requested local research artifacts and <=6-page English working draft; human-author submission review is not claimed','requirement_evidence':checks,'paper_pages':5,'archive_sha256':bundle['sha256'],'archive_files':bundle['file_count'],'remaining_required_local_work':[],'remaining_author_submission_review':p5['remaining_author_review'],'contribution_limitation':'Small selector implemented and evaluated; final tests do not prove universal improvement or guarantee conference acceptance.'}
with (out/'goal_completion_audit.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({'passed':True,'requirements_checked':len(checks),'paper_pages':5,'archive_files':bundle['file_count'],'remaining_required_local_work':[]}))
