Accept G1 with explicitly disclosed original-paper access limitations. Proceed with bounded known temporal/RRF baselines, no novelty claim or test-based parameter choice.
