Immutable freeze created after code regression and gallery metadata identity, before independent performance. All comparison/sensitivity/latency choices fixed, including negative adaptive direction.
