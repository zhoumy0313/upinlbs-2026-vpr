Offline gallery build, not online query latency. Encoder/preprocessing/cache arrays identified by exact hashes before independent performance.
