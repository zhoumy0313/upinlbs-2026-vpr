Read-only exact remote ref verification following successful authorized V2 backup. Original main/tag intact.
