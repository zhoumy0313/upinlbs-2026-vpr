Backup of new V2 branch; main and frozen V1 tag retained.
